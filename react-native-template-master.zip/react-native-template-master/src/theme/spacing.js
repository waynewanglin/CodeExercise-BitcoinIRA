export const spacing = {
  xs: 8,
  s: 16,
  m: 24,
  l: 32,
  xl: 40,
};
