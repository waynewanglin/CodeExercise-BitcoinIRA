import LocalizedStrings from 'react-native-localization';
import { en } from '@/localization/en';

export const strings = new LocalizedStrings({ en });
