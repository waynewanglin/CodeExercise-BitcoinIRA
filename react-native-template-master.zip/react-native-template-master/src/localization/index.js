export { strings } from '@/localization/Localization';
