export { default as homeIcon } from '@/assets/ic_home/ic_home.png';
export { default as settingsIcon } from '@/assets/ic_settings/ic_settings.png';
