export const NAVIGATION = {
  home: 'Home',
  login: 'Login',
  profile: 'Profile',
};
